export class Route {
    constructor({
        id = null,
        name,
        description = "",
        distanceKm = 0,
        durationMinutes = 0,
        difficulty = "fácil",
        ownerId = null,
        status = "saved",
        completedBy = []
    }) {
        Object.assign(this, {
            id, name, description, distanceKm, durationMinutes,
            difficulty, ownerId, status, completedBy
        });
    }

    calculateProgress(steps = []) {
        if (!steps.length) return 0;
        const completed = steps.filter((step) => step.completed).length;
        return Math.round((completed / steps.length) * 100);
    }

    markCompleted() {
        this.status = "completed";
        return this;
    }

    markCompletedBy(userId) {
        const normalizedId = String(userId);
        if (!this.completedBy.includes(normalizedId)) {
            this.completedBy.push(normalizedId);
        }
        return this;
    }
}
