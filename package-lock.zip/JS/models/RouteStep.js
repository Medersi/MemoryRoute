export class RouteStep {
    constructor({
        id = null,
        routeId,
        order,
        title = "",
        instruction,
        image = "logo.png",
        landmark = "",
        completed = false
    }) {
        Object.assign(this, { id, routeId, order, title, instruction, image, landmark, completed });
    }

    markCompleted() {
        this.completed = true;
        return this;
    }

    reset() {
        this.completed = false;
        return this;
    }
}
